<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group">
                <label for="proveedor">Fecha</label>
                <p><?php echo e($total->fecha); ?></p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-body">            

                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                    <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">
                        <thead style="background-color:#A9D0F5">
                            <th>Negocio</th>
                            <th>Efectivo</th>
                            <th>Tarjeta</th>
                            <th>Subtotal</th>
                        </thead>
                        <tfoot>
                            <tr style="background-color:#c0c0c0">
                                <th  colspan="0"><p align="left">TOTALES</p></th>
                                <th  colspan="0"><p align="left"><?php echo e($total->total_efectivo); ?></p></th>
                                <th  colspan="0"><p align="left"><?php echo e($total->total_tarjeta); ?></p></th>
                                <th  colspan="0"><p align="left"><?php echo e($total->total_gral); ?></p></th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php foreach($detalles as $det): ?>
                            <tr>
                                <td><?php echo e($det->nombre); ?></td>
                                <td>$/. <?php echo e($det->efectivo); ?></td>
                                <td>$/. <?php echo e($det->tarjeta); ?></td>
                                <td>$/. <?php echo e($det->sub_total); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                 </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">
                <div class="form-group">
                  <a href="<?php echo e(url('reportotales',$total->id)); ?>" target="_blank"><button title="Reporte" class="btn btn-warning"><i class="fa fa-print" aria-hidden="true"></i></button></a>
                </div>
            </div>
    </div>   
<?php $__env->startPush('scripts'); ?>
<script>
$('#liVentas').addClass("treeview active");
$('#liVentass').addClass("active");
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>