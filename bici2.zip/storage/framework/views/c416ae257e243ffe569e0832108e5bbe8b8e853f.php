<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de Materiales <a href="material/create"><button class="btn btn-success">Nuevo</button></a> <a href="<?php echo e(url('reportemateriales')); ?>" target="_blank"><button class="btn btn-info">Reporte</button></a></h3>
		<?php echo $__env->make('deposito.material.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Nombre</th>
					<th>Código</th>
					<th>Categoría</th>
					<th>Stock</th>
					<th>Imagen</th>
					<th>Estado</th>
					<th>Opciones</th>
				</thead>
               <?php foreach($materiales as $mat): ?>
				<tr>
					<td><?php echo e($mat->idmaterial); ?></td>
					<td><?php echo e($mat->nombre); ?></td>
					<td><?php echo e($mat->codigo); ?></td>
					<td><?php echo e($mat->rubro); ?></td>
					<td><?php echo e($mat->stock); ?></td>
					<td>
						<img src="<?php echo e(asset('imagenes/materiales/'.$mat->imagen)); ?>" alt="<?php echo e($mat->nombre); ?>" height="100px" width="100px" class="img-thumbnail">
					</td>
					<td><?php echo e($mat->estado); ?></td>
					<td>
						<a href="<?php echo e(URL::action('MaterialController@edit',$mat->idmaterial)); ?>"><button class="btn btn-info">Editar</button></a>
                         <a href="" data-target="#modal-delete-<?php echo e($mat->idmaterial); ?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
					</td>
				</tr>
				<?php echo $__env->make('deposito.material.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; ?>
			</table>
		</div>
		<?php echo e($materiales->render()); ?>

	</div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
$('#liAlmacen').addClass("treeview active");
$('#liArticulos').addClass("active");
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>