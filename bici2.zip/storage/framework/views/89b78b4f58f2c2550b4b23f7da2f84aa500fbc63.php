<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Nuevo Incidente</h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php foreach($errors->all() as $error): ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>
		</div>
	</div>
			<?php echo Form::open(array('url'=>'menu/incidente','method'=>'POST','autocomplete'=>'off')); ?>

            <?php echo e(Form::token()); ?>

    <div class="row">
    	<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="form-group">
                <label>Tipo</label>
                <select name="tipo" class="form-control">
                       <option value="Software">Software</option>
                       <option value="Hardware">Hardware</option>
                       <option value="Otras">Otras</option>
                </select>
            </div>
        </div>
        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="form-group">
                <label for="descripcion">Descripción</label>
                <input type="text" name="descripcion" value="<?php echo e(old('descripcion')); ?>" class="form-control" placeholder="Descripción...">
            </div>
        </div>
    	<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
    		<div class="form-group">
    			<label>Impacto</label>
    			<select name="impacto" class="form-control">
                       <option value="Menor">Menor</option>
                       <option value="Normal">Normal</option>
                       <option value="Alto">Alto</option>
    			</select>
    		</div>
    	</div>
    	<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
    		<div class="form-group">
            	<label for="area">Area</label>
            	<input type="text" name="area" value="<?php echo e(old('area')); ?>" class="form-control" placeholder="Area...">
            </div>
    	</div>
    	<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
    		<div class="form-group">
            	<label for="tecnico">Tecnico</label>
            	<input type="text" name="tecnico" value="<?php echo e(old('tecnico')); ?>" class="form-control" placeholder="Tecnico...">
            </div>
    	</div>
    	<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
    		<div class="form-group">
            	<button class="btn btn-primary" type="submit">Guardar</button>
            	<button class="btn btn-danger" type="reset">Cancelar</button>
            </div>
    	</div>
    </div>   
			<?php echo Form::close(); ?>		
<?php $__env->startPush('scripts'); ?>
<script>
$('#liVentas').addClass("treeview active");
$('#liClientes').addClass("active");
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>