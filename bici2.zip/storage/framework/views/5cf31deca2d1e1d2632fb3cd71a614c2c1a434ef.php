<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <h3>Nuevo Cierre</h3>
        <?php if(count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</div>
    <?php echo Form::model($total,['method'=>'PATCH','route'=>['menu.recaudacion.update',$total->id]]); ?>

    <?php echo e(Form::token()); ?>

                
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-body">
                <?php /* <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <div class="form-group">
                        <label>Negocio</label>
                        <select name="pidsucursal" class="form-control selectpicker" id="pidsucursal" data-live-search="true">
                            <?php foreach($sucursales as $suc): ?>
                            <option value="<?php echo e($suc->id); ?>_<?php echo e($suc->nombre); ?>"><?php echo e($suc->nombre); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div> */ ?>
                <?php /* <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">
                    <div class="form-group">
                        <label for="efectivo">Efectivo</label>
                    <input type="number" name="pefectivo" id="pefectivo" class="form-control" value="<?php echo e($total->to); ?>">
                    </div>
                </div>
                <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">
                    <div class="form-group">
                        <label for="tarjeta">Tarjetas</label>
                        <input type="number"  name="ptarjeta" id="ptarjeta" class="form-control" 
                        placeholder="Monto Tarjetas">
                    </div>
                </div> */ ?>
                <?php /* <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">
                    <div class="form-group">
                        <label for="sub_total">Sub-Total</label>
                        <input type="number" name="psubtotal" id="psubtotal" class="form-control" value="0">
                    </div>
                </div>  */ ?>
                
                <?php /* <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">
                    <div class="form-group">
                        <label for=""></label>
                       <button type="button" id="bt_add" class="btn btn-primary" class="form-control">Agregar</button>
                    </div>
                </div>

                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                    <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">
                        <thead style="background-color:#A9D0F5">
                            <th>Opciones</th>
                            <th>Negocio</th>
                            <th>Efectivo</th>
                            <th>Tarjeta</th>
                            <th>Subtotal</th>
                        </thead>
                        <tfoot>
                            <tr>
                                <th  colspan="5"><p align="right">TOTAL EFECTIVO:</p></th>
                                <th><p align="right"><span id="total_efectivo">$/. </span> <input type="hidden" name="total_efectivo" id="tefectivo"></p></th>
                            </tr>
                            <tr>
                                <th colspan="5"><p align="right">TOTAL TARJETAS:</p></th>
                                <th><p align="right"><span id="total_tarjeta">$/. </span></p><input type="hidden" name="total_tarjeta" id="ttarjeta"></th>
                            </tr>
                            <tr>
                                <th  colspan="5"><p align="right">TOTAL GENERAL:</p></th>
                                <th><p align="right"><span align="right" id="total_gral">$/. </span><input type="hidden" name="total_gral" id="tgral"></p></th>
                            </tr>
                            <input type="hidden" name="estado" value="Activo">
                        </tfoot>
                        <tbody>
                            
                        </tbody>
                    </table
                 </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">
        <div class="form-group">
            <input name="_token" value="<?php echo e(csrf_token()); ?>" type="hidden"></input>
            <button class="btn btn-primary" id="save"type="submit">Guardar</button>
            <button class="btn btn-danger" type="reset">Cancelar</button>
        </div>
    </div>   */ ?>
                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                    <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">
                        <thead style="background-color:#A9D0F5">
                            <th>Negocio</th>
                            <th>Efectivo</th>
                            <th>Tarjeta</th>
                            <th>Subtotal</th>
                        </thead>
                        <tfoot>
                            <tr>
                                <th  colspan="4"><p align="right">TOTAL EFECTIVO:</p></th>
                                <th><p align="right"><input type="text" name="total_efectivo" class="form-control" value="<?php echo e($total->total_efectivo); ?>"></p></th>
                            </tr>
                            <tr>
                                <th  colspan="4"><p align="right">TOTAL TARJETAS:</p></th>
                                <th><p align="right"><input type="text" name="total_tarjeta" class="form-control" value="<?php echo e($total->total_tarjeta); ?>"></p></th>
                            </tr>
                            <tr>
                                <th  colspan="4"><p align="right">MONTO TOTAL:</p></th>
                            <th><p align="right"><input type="text" name="total_gral" class="form-control" value="<?php echo e($total->total_gral); ?>"></p></th>
                            </tr>  
                        </tfoot>
                        <tbody>
                            <?php foreach($detalles as $det): ?>
                            <tr>
                                <td><input type="text" name="negocio"  class="form-control" value="<?php echo e($det->nombre); ?>"></td>
                                <td><input type="text" name="efectivo"  class="form-control" value="<?php echo e($det->efectivo); ?>"></td>
                                <td><input type="text" name="tarjeta"  class="form-control" value="<?php echo e($det->tarjeta); ?>"></td>
                                <td><input type="text" name="sub_total"  class="form-control" value="<?php echo e($det->sub_total); ?>"></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                 </div>
                </div>
                 <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">
                    <div class="form-group">
                        <input name="_token" value="<?php echo e(csrf_token()); ?>" type="hidden"></input>
                        <button class="btn btn-primary" id="save"type="submit">Guardar</button>
                        <button class="btn btn-danger" type="reset">Cancelar</button>
                    </div>
                </div>  
        </div>
<?php echo Form::close(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
$('#liVentas').addClass("treeview active");
$('#liVentass').addClass("active");
  
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>