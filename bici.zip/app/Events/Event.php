<?php

namespace adm\Events;

abstract class Event
{
    //
}
