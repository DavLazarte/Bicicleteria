<?php

namespace adm\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use adm\Http\Requests;
use Illuminate\Support\Facades\Redirect;
use adm\DetalleTotal;
use adm\Total;
use DB;
use Response;
use Illuminate\Support\Collection;

class TotalController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request)
        {
           $searchText=trim($request->get('searchText'));
           $totals=DB::table('totals')
            ->where('created_at','LIKE','%'.$searchText.'%')
            ->where('estado','=','Activo')
            ->orderBy('id','desc')
            ->paginate(10);
            return view('menu.totales.index', compact('searchText', 'totals'));

        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $sucursales=DB::table('sucursals')->where('estado','=','Activa')->get();
    
        return view("menu.totales.create",compact('sucursales'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
         try{
            DB::beginTransaction();
            $total=new Total;
            $total->total_efectivo=$request->get('total_efectivo');
            $total->total_tarjeta=$request->get('total_tarjeta');
            $total->total_gral=$request->get('total_gral');
            $total->estado=$request->get('estado');
            $total->save();
            
            $negocio = $request->get('negocio');
            $efectivo = $request->get('efectivo');
            $tarjeta = $request->get('tarjeta');
            $sub_total = $request->get('sub_total');
            
             $cont = 0;
            
            while($cont < count($negocio)){
                $detalle = new DetalleTotal();
                $detalle->idtotal= $total->id; 
                $detalle->negocio= $negocio[$cont];
                $detalle->efectivo= $efectivo[$cont];
                $detalle->tarjeta= $tarjeta[$cont];
                $detalle->sub_total= $sub_total[$cont];
                $detalle->save();
                $cont=$cont+1;
            }

             DB::commit();

         }catch(\Exception $e)
         {
               DB::rollback();
         }

        return Redirect::to('menu/recaudacion');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $total=DB::table('totals')
            ->where('id','=',$id)
            ->first();

        $detalles=DB::table('detalle_totals as dt')
             ->join('sucursals as s','dt.negocio','=','s.id')
             ->select('s.nombre','dt.efectivo','dt.tarjeta','dt.sub_total')
             ->where('dt.idtotal','=',$id)
             ->get();
        return view("menu.totales.show",compact('total','detalles'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $total=Total::findOrFail($id);
        $total->estado='Cancelada';
        $total->update();
        return Redirect::to('menu/recaudacion');
    }
}
