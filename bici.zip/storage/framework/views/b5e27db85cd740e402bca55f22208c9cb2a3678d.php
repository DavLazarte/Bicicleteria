<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group">
                <label for="proveedor">Fecha</label>
                <p><?php echo e($total->created_at); ?></p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-body">            

                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                    <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">
                        <thead style="background-color:#A9D0F5">
                            <th>Negocio</th>
                            <th>Efectivo</th>
                            <th>Tarjeta</th>
                            <th>Subtotal</th>
                        </thead>
                        <tfoot>
                            <tr>
                                <th  colspan="4"><p align="right">TOTAL EFECTIVO:</p></th>
                                <th><p align="right">$/. <?php echo e($total->total_efectivo); ?></p></th>
                            </tr>
                            <tr>
                                <th  colspan="4"><p align="right">TOTAL TARJETAS:</p></th>
                                <th><p align="right">$/. <?php echo e($total->total_tarjeta); ?></p></th>
                            </tr>
                            <tr>
                                <th  colspan="4"><p align="right">MONTO TOTAL:</p></th>
                                <th><p align="right">$/. <?php echo e($total->total_gral); ?></p></th>
                            </tr>  
                        </tfoot>
                        <tbody>
                            <?php foreach($detalles as $det): ?>
                            <tr>
                                <td><?php echo e($det->nombre); ?></td>
                                <td>$/. <?php echo e($det->efectivo); ?></td>
                                <td>$/. <?php echo e($det->tarjeta); ?></td>
                                <td>$/. <?php echo e($det->sub_total); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                 </div>
            </div>
        </div>
        
    </div>   
<?php $__env->startPush('scripts'); ?>
<script>
$('#liVentas').addClass("treeview active");
$('#liVentass').addClass("active");
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>