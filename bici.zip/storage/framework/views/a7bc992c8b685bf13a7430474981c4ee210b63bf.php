<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3>Listado de Cierres<a href="recaudacion/create"><button class="btn btn-success">Nuevo</button></a> </h3>
        <?php echo $__env->make('menu.totales.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Fecha</th>
                    <th>Total Efectivo</th>
                    <th>Total Tarjeta</th>
                    <th>Total General</th>
                    <th>Estado</th>
                    <th>Opciones</th>
                </thead>
               <?php foreach($totals as $tot): ?>
                <tr>
                    <td><?php echo e(Carbon\Carbon::parse($tot->created_at)->format('d-m-Y')); ?></td>
                    <td><?php echo e($tot->total_efectivo); ?></td>
                    <td><?php echo e($tot->total_tarjeta); ?></td>
                    <td><?php echo e($tot->total_gral); ?></td>
                    <td><?php echo e($tot->estado); ?></td>
                    <td>
                        <a href="<?php echo e(URL::action('TotalController@show',$tot->id)); ?>"><button class="btn btn-primary">Detalles</button></a>
                        <?php /* <a href="<?php echo e(URL::action('TotalController@edit',$tot->id)); ?>"><button class="btn btn-success">Actualizar</button></a> */ ?>
                        <a href="" data-target="#modal-delete-<?php echo e($tot->id); ?>" data-toggle="modal"><button class="btn btn-danger">Anular</button></a>
                    </td>
                </tr>

                <?php echo $__env->make('menu.totales.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; ?>
            </table>
        </div>
        <?php echo e($totals->render()); ?>

    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
$('#liVentas').addClass("treeview active");
$('#liVentass').addClass("active");
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>