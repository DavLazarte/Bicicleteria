@extends ('layouts.admin')
@section ('contenido')
    <div class="row">
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group">
                <label for="proveedor">Fecha</label>
                <p>{{$total->created_at}}</p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-body">            

                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                    <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">
                        <thead style="background-color:#A9D0F5">
                            <th>Negocio</th>
                            <th>Efectivo</th>
                            <th>Tarjeta</th>
                            <th>Subtotal</th>
                        </thead>
                        <tfoot>
                            <tr>
                                <th  colspan="4"><p align="right">TOTAL EFECTIVO:</p></th>
                                <th><p align="right">$/. {{$total->total_efectivo}}</p></th>
                            </tr>
                            <tr>
                                <th  colspan="4"><p align="right">TOTAL TARJETAS:</p></th>
                                <th><p align="right">$/. {{$total->total_tarjeta}}</p></th>
                            </tr>
                            <tr>
                                <th  colspan="4"><p align="right">MONTO TOTAL:</p></th>
                                <th><p align="right">$/. {{$total->total_gral}}</p></th>
                            </tr>  
                        </tfoot>
                        <tbody>
                            @foreach($detalles as $det)
                            <tr>
                                <td>{{$det->nombre}}</td>
                                <td>$/. {{$det->efectivo}}</td>
                                <td>$/. {{$det->tarjeta}}</td>
                                <td>$/. {{$det->sub_total}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                 </div>
            </div>
        </div>
        
    </div>   
@push ('scripts')
<script>
$('#liVentas').addClass("treeview active");
$('#liVentass').addClass("active");
</script>
@endpush
@endsection